PRIYANSHI E-COMMERCE FUNCTIONAL UPDATE

Files:
- index.html
- assets/js/script.js

How to apply:
1. Keep your existing assets folder (images and CSS).
2. Replace your existing index.html with this index.html.
3. Replace assets/js/script.js with the supplied script.js.
4. Open index.html with Live Server in VS Code.

Features:
- Add to cart, quantity controls, remove item, and cart count.
- Checkout summary with subtotal, SAVE10 (10% off), shipping, and final total.
- Demo checkout, past order history, and saved customer details.
- INR display, using ₹83 per former US dollar as a simple conversion.
- Product search.
- Cart, order and customer details are saved in browser localStorage on this device.

Important:
This is a front-end demo. Orders and customer details are not saved to a server and are not shared between browsers/devices. No real payment is processed. Clear browser site data/localStorage to remove saved demo information.
